<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <style>
        <?php echo $css ?? ''; ?>

    </style>
</head>

<body>
    <?php echo $content ?? ''; ?>

</body>

</html><?php /**PATH C:\Users\Utente\Desktop\Progetti\S73F\cmspordini-inertia-themed\resources\views/emails/exception.blade.php ENDPATH**/ ?>