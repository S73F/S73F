<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <style>
        {!! $css ?? '' !!}
    </style>
</head>

<body>
    {!! $content ?? '' !!}
</body>

</html>